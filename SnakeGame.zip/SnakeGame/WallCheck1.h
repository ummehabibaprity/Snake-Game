#ifndef WallCheck1_H_INCLUDED
#define WallCheck1_H_INCLUDED




void WallCheck1() 
{
	
	//For snake 1(HARD LEVEL)
	if(x[0] >=245 && x[0] <=253 && y[0]>=297 && y[0] <=400 && mode==3 )  //For left obstacle
	{
		mode=5; 
		PlaySound("gv.wav",NULL, SND_ASYNC);
		                                                 
	}

	if(x[0]>=445  && x[0]<=453 && y[0]>=297 && y[0]<=400 && mode==3) //For right obstacle
	{
		mode=5;
		PlaySound("gv.wav",NULL, SND_ASYNC);
		                                    
		
	}


	//##FOR SNAKE 1 ( VERY HARD LEVEL) 


	if(x[0] >=248 && x[0] <=257 && y[0]>=298 && y[0] <=401 && mode==77 )  //For left obstacle
	{
		mode=5;
			
	}

	if(x[0]>=448  && x[0]<=457 && y[0]>=298 && y[0]<=401 && mode==77) //For right obstacle
	{
		mode=5;
		
	}
	if(x[0] >=248 && x[0] <=257 && y[0]>=118 && y[0]<=222 && mode==77 )  //For left lower obstacle
	{
		mode=5;
		
	}
	if(x[0] >=248 && x[0] <=257 && y[0]>=478 && y[0]<=582 && mode==77 )  //For left upper obstacle
	{
		mode=5;
		
	}
	if(x[0] >=123 && x[0] <=227 && y[0]>=248 && y[0]<=257 && mode==77 )  //For left middle lower obstacle
	{
		mode=5; 
		
	}
	if(x[0] >=123 && x[0] <=227 && y[0]>=433 && y[0]<=442 && mode==77 )  //For left middle upper obstacle
	{
		mode=5;
		
	}
	if(x[0] >=478 && x[0] <=582 && y[0]>=433 && y[0]<=442 && mode==77 )  //For right middle upper obstacle
	{
		mode=5; 
		
	}
	if(x[0] >=448 && x[0] <=457 && y[0]>=478 && y[0]<=582 && mode==77 )  //For right upper obstacle
	{
		mode=5;                                                    
	}
	if(x[0] >=448 && x[0] <=457 && y[0]>=118 && y[0] <=222 && mode==77 )  //For right lower obstacle
	{
		mode=5;                                                    
	}
	if(x[0] >=478 && x[0] <=582 && y[0]>=248 && y[0] <=257 && mode==77 )  //For left obstacle
	{
		mode=5;                                                    
	}


 
	//For snake 2(HARD LEVEL)
		if(x2[0] >=298.5 && x2[0] <=401.5 && y2[0]>=448.5 && y2[0] <=457.5 && mode==33 )  //For higher obstacle
	{
		mode=5;                                                    
	}

	if(x2[0]>=298  && x2[0]<=397 && y2[0]>=248 && y2[0]<=255 && mode==33)   //For lower obstacle
	{
		mode=5;
	}


	//FOR SNAKE 2 ( VERY HARD)
	if(x2[0] >=149 && x2[0] <=301 && y2[0]>=544 && y2[0] <=551 && mode==99 )  
	{
		mode=5;                                                    
	}

	if(x2[0] >=149 && x2[0] <=301 && y2[0]>=399 && y2[0] <=406 && mode==99 )  
	{
		mode=5;                                                    
	}

	if(x2[0]>=149  && x2[0]<=251 && y2[0]>=444 && y2[0]<=451 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=149  && x2[0]<=251 && y2[0]>=499 && y2[0]<=506 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=244  && x2[0]<=251 && y2[0]>=449 && y2[0]<=501 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=299  && x2[0]<=306 && y2[0]>=399 && y2[0]<=551 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=551 && y2[0]>=544 && y2[0]<=551 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=551 && y2[0]>=444 && y2[0]<=452 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=551 && y2[0]>=499 && y2[0]<=506 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=551 && y2[0]>=399 && y2[0]<=406 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=456 && y2[0]>=449 && y2[0]<=501 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=406 && y2[0]>=399 && y2[0]<=551 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=551 && y2[0]>=154 && y2[0]<=161 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=551 && y2[0]>=199 && y2[0]<=206 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=551 && y2[0]>=299 && y2[0]<=306 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=551 && y2[0]>=249 && y2[0]<=256 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=449  && x2[0]<=456 && y2[0]>=199 && y2[0]<=251 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=399  && x2[0]<=406 && y2[0]>=154 && y2[0]<=306 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=149  && x2[0]<=301 && y2[0]>=154 && y2[0]<=161 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=149  && x2[0]<=251 && y2[0]>=199 && y2[0]<=206 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=244  && x2[0]<=251 && y2[0]>=199 && y2[0]<=251 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=299  && x2[0]<=306 && y2[0]>=154 && y2[0]<=306 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=149  && x2[0]<=301 && y2[0]>=299 && y2[0]<=306 && mode==99)   
	{
		mode=5;
	}

	if(x2[0]>=149  && x2[0]<=251 && y2[0]>=249 && y2[0]<=256 && mode==99)   
	{
		mode=5;
	}
	
}



#endif WallCheck1_H_INCLUDED
