#ifndef ControlSnake_H_INCLUDED
#define ControlSnake_H_INCLUDED
#include "WallCheck1.h"
#include "FoodCheck.h"
#include "SnakeCheck.h"
#include "LimitCheck.h"
#include "Background.h"




//### CODES FOR CONTROLLING SNAKES

 void MoveUp_FromLeft()
{

	 if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(0);

      x_p[0]=x[0];
	  y_p[0]=y[0];
      y[0]=y[0]+7;



	  	  
	  for(int i=1;i<=l_rec;i++){
	      x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];

	  }	  	


	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	 }

	 if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(0);

      x_p2[0]=x2[0]-3;
	  y_p2[0]=y2[0]-2.5;
      y2[0]=y2[0]+7;
	  


	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];

	  }	  	
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();



	 }

 
	 if(mode==23)
	 {
	for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(0);
      
	  x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      y3[0]=y3[0]+7;
	 

	  	  
	  for(int i=1;i<=l_rec3;i++){
	      x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }

      x_p4[0]=x4[0]-3;
	  y_p4[0]=y4[0]-2.5;
      y4[0]=y4[0]+7;


	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];

	  }	  	
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();


	 }

}


  void MoveUp_FromRight()
{
if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(1);

	 
      x_p[0]=x[0];
	  y_p[0]=y[0];
      y[0]=y[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
}

if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(1);

	 
      x_p2[0]=x2[0]-3;
	  y_p2[0]=y2[0]-2.5;
      y2[0]=y2[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
      
}


	 if(mode==23)
	 {
	for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(1);
      
	  x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      y3[0]=y3[0]+7;
	 

	  	  
	  for(int j=1;j<=l_rec3;j++){
	      x_p3[j]=x3[j];
	      y_p3[j]=y3[j];
		  x3[j]=x_p3[j-1];
		  y3[j]=y_p3[j-1];
	  }

      x_p4[0]=x4[0]-3;
	  y_p4[0]=y4[0]-2.5;
      y4[0]=y4[0]+7;

	  	  
	  for(int i=1;i<=l_rec4;i++){
	      x_p4[i]=x4[i];
	      y_p4[i]=y4[i];
		  x4[i]=x_p4[i-1];
		  y4[i]=y_p4[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
      
}
	  	

}




void MoveDown_FromLeft()
{
if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(2);
	
      x_p[0]=x[0];
	  y_p[0]=y[0];
      y[0]=y[0]-7;
	 

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }	  

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
}


if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(2);
	
      x_p2[0]=x2[0]-3;
	  y_p2[0]=y2[0]-5;
      y2[0]=y2[0]-7;
	

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }	  
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

}


	 if(mode==23)
	 {
	for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(2);
      
	  x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      y3[0]=y3[0]-7;
	  

	  	  
	  for(int j=1;j<=l_rec3;j++){
	      x_p3[j]=x3[j];
	      y_p3[j]=y3[j];
		  x3[j]=x_p3[j-1];
		  y3[j]=y_p3[j-1];
	  }
	
      x_p4[0]=x4[0]-3;
	  y_p4[0]=y4[0]-5;
      y4[0]=y4[0]-7;

	  	  
	  for(int i=1;i<=l_rec4;i++){
	      x_p4[i]=x4[i];
	      y_p4[i]=y4[i];
		  x4[i]=x_p4[i-1];
		  y4[i]=y_p4[i-1];
	  }	  
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();	
	 }

	  
}

void MoveDown_FromRight()
{
	if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(3);
	
      x_p[0]=x[0];
	  y_p[0]=y[0];
      y[0]=y[0]-7;
	 

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	}

		if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(3);
	
      x_p2[0]=x2[0]-3;
	  y_p2[0]=y2[0]-5;
      y2[0]=y2[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec2;i++){
	      x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}


	if(mode==23){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(3);
	
      x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      y3[0]=y3[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec3;i++){
	      x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }
      x_p4[0]=x4[0]-3;
	  y_p4[0]=y4[0]-5;
      y4[0]=y4[0]-7;

	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}	  
}


void MoveLeft_FromUp(){

	if(mode==2 || mode==3 || mode==77 ){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(4);
	  
      x_p[0]=x[0];
	  y_p[0]=y[0];
      x[0]=x[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	}


		if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(4);
	  
      x_p2[0]=x2[0]-4;
	  y_p2[0]=y2[0]-3.5;
      x2[0]=x2[0]-7;
	 

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}


	if(mode==23){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(4);
	  
      x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      x3[0]=x3[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec3;i++){
	  x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }	 

      x_p4[0]=x4[0]-4;
	  y_p4[0]=y4[0]-3.5;
      x4[0]=x4[0]-7;

	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}	  

}

void MoveLeft_FromDown()
{
	if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(5);
	  
      x_p[0]=x[0];
	  y_p[0]=y[0];
      x[0]=x[0]-7;
	 

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	
	} 

	if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(5);
	  
      x_p2[0]=x2[0]-4;
	  y_p2[0]=y2[0]-3.5;
      x2[0]=x2[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	
	} 

	if(mode==23){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(5);
	  
      x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      x3[0]=x3[0]-7;
	  

	  	  
	  for(int i=1;i<=l_rec3;i++){
	      x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }
      x_p4[0]=x4[0]-4;
	  y_p4[0]=y4[0]-3.5;
      x4[0]=x4[0]-7;

	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	
	} 
	  


}



void MoveRight_FromUp()
{
	if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(6);
	  
      x_p[0]=x[0];
	  y_p[0]=y[0];
      x[0]=x[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	
	}

	if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(6);
	  
      x_p2[0]=x2[0]-2;
	  y_p2[0]=y2[0]-3.5;
      x2[0]=x2[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	
	}

	if(mode==23){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(6);
	  
      x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      x3[0]=x3[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec3;i++){
	      x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }	 

      x_p4[0]=x4[0]-2;
	  y_p4[0]=y4[0]-3.5;
      x4[0]=x4[0]+7;

	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	
	}	  

}

void MoveRight_FromDown()
{

	if(mode==2 || mode==3 || mode==77){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(7);
	  
       x_p[0]=x[0];
	  y_p[0]=y[0];
      x[0]=x[0]+7;
	 

	  	  
	  for(int i=1;i<=l_rec;i++){
	  x_p[i]=x[i];
	      y_p[i]=y[i];
		  x[i]=x_p[i-1];
		  y[i]=y_p[i-1];
	  }

      FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();
	}

	if(mode==22 || mode==33 || mode==99){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(7);
	  
       x_p2[0]=x2[0]-2;
	  y_p2[0]=y2[0]-3.5;
      x2[0]=x2[0]+7;
	  sample++;

	  	  
	  for(int i=1;i<=l_rec2;i++){
	  x_p2[i]=x2[i];
	      y_p2[i]=y2[i];
		  x2[i]=x_p2[i-1];
		  y2[i]=y_p2[i-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}

		if(mode==23){
	 for(int k=0;k<=8;k++){
	  iPauseTimer(k);
	 }
      iResumeTimer(7);
	  
      x_p3[0]=x3[0];
	  y_p3[0]=y3[0];
      x3[0]=x3[0]+7;
	  

	  	  
	  for(int i=1;i<=l_rec3;i++){
	      x_p3[i]=x3[i];
	      y_p3[i]=y3[i];
		  x3[i]=x_p3[i-1];
		  y3[i]=y_p3[i-1];
	  }
      x_p4[0]=x4[0]-2;
	  y_p4[0]=y4[0]-3.5;
      x4[0]=x4[0]+7;

	  	  
	  for(int j=1;j<=l_rec4;j++){
	      x_p4[j]=x4[j];
	      y_p4[j]=y4[j];
		  x4[j]=x_p4[j-1];
		  y4[j]=y_p4[j-1];
	  }
	  FoodCheck();
	  LimitCheck();
	  WallCheck1();
	  SnakeCheck();

	}
}


#endif ControlSnake_H_INCLUDED
