#ifndef Background_H_INCLUDED
#define Background_H_INCLUDED
#include "FoodCheck.h"
//star 1
	int fx = 20;//rand()%(400-34);
		            int fy = 600;
		            int fw=26;
		            int fh=26;
					int fs=3;
					//for star2
					int fx1 = 80;//rand()%(400-34);
		            int fy1 = 600;
		            
					//for star 3
					int fx2 = 430;//rand()%(400-34);
		            int fy2 = 600;
		            
					//for star 4
					int fx3 = 500;//rand()%(400-34);
		            int fy3 = 600;

void Backround()
{
	
	
			iShowBMP(0,0,"night2.bmp");
	
				if(fy<=0){
						  fx=rand()%(600-fw);

						  fy=600;
					}
					else{
						fy-=fs;
					
					}


	
				




	iShowBMP2(fx,fy,"star.bmp",0);
					if(fy1<=20){
						  fx1=rand()%(600-fw);

						  fy1=600;
					}
					else{
						fy1-=fs;
					
					}
	iShowBMP2(fx1,fy1,"star.bmp",0);
						if(fy2<=100){
						  fx2=rand()%(600-fw);

						  fy2=600;
					}
					else{
						fy2-=fs;
					
					}
	iShowBMP2(fx2,fy2,"star.bmp",0);
						if(fy3<=480){
						  fx3=rand()%(700-fw);

						  fy3=640;
					}
					else{
						fy3-=fs;
					
					}
	iShowBMP2(fx3,fy3,"star.bmp",0);
							if(fy3<=580){
						  fx3=rand()%(700-fw);

						  fy3=680;
					}
					else{
						fy3-=fs;
					
					}

}

#endif Background_H_INCLUDED
