#ifndef SnakeCheck_H_INCLUDED
#define SnakeCheck_H_INCLUDED

void SnakeCheck(){  //GAME OVERs when the head touches the body of snake
	
	//SNAKE 1

	if(mode==2 || mode==3)
	{
		for( int z=1;z<=l_rec;z++)
		{
			if(x[0]==x[z] &&  y[0]==y[z] )
				
			{
				mode=5;
				
			   
			}		 
		}
	}


	//SNAKE 2

	if(mode==22 || mode==33)
	{
		for( int y=1;y<=l_rec2;y++)
		{
			if(x2[0]>=x2[y] && x2[0]<=x2[y]+7 &&  y2[0]>=y2[y] && y2[0]<=y2[y]+7 )
				
			{
				mode=5;
			   
			}		 
		}
	}
}
	//This function is for SPECIAL FOOD to call after 10 points again & again

void Special()
{  TF=0;
	for(int x=1;x<=200;x++){
		
	
		if( count == 10*x)
		{	
			
			if(sample==1001 && p_sam==1 ) {
				sample = -1000;
				
			}
	
			if(sample>=0 && sample<= 1000 && p_sam==0  )
			{
				TF=1;
		
				iSetColor(0,256,0);
				iFilledCircle(sfp_x,sfp_y,4);
				iLine(sfp_x,sfp_y+3,sfp_x+4,sfp_y+7);
				if(sample==1000) p_sam=1;
				
			}
			sample++;
			printf("%d\n",count);
			
		}
	}
}



#endif SnakeCheck_H_INCLUDED