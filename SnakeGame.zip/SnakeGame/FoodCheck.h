#ifndef FoodCheck_H_INCLUDED
#define FoodCheck_H_INCLUDED
# include "Background.h"

int fp_x,fp_y,sfp_x,sfp_y,sample=0,count=0,p_sam=0,TF=0;
int l_rec=4,l_rec2=4,l_rec3=4,l_rec4=4; 
double x[1000],y[1000],x_p[1000],y_p[1000];
double x2[1000],y2[1000],x_p2[1000],y_p2[1000];
double x3[1000],y3[1000],x_p3[1000],y_p3[1000];
double x4[1000],y4[1000],x_p4[1000],y_p4[1000];
bool musicOn=true;
bool music2On=true;


void FoodCheck()
{

	//### For snake 1 ###

    //NORMAL FOOD 

	if((mode==2 || mode==3) && fp_x<=x[0]+7 && fp_x>=x[0] && fp_y<=y[0]+7 && fp_y>=y[0])
	{
		l_rec++;
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;


		while(fp_x <=104 || fp_x >=597 || fp_y<=103 || fp_y >=596 )
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105; 
		}

		if(fp_x<104 || fp_x>597 || fp_y<103 || fp_y>596){
			printf("%d  %d\n",fp_x,fp_y);
		}
 
		
 
		//HARD LEVEL (WALLS)
		while(fp_x >=245 && fp_x <=260 && fp_y>=295 && fp_y <=405 ||  fp_x>=445 && fp_x<=460 && fp_y>=295 && fp_y<=405)
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;   
		}
		count++;
		if(count++) 
		{
			if(music2On){
	
		musicOn=false;
		PlaySound("Eat.wav",NULL, SND_ASYNC);
		
	}
			p_sam=0;
			sample=0;
		}
		score++;
		printf("%d\n",score);  
        

		

	
	}


	//SPECIAL FOOD

if((mode==2 || mode==3) && sfp_x<=x[0]+7 && sfp_x>=x[0] && sfp_y<=y[0]+7 && sfp_y>=y[0] && TF==1)
	{

		l_rec=l_rec+2;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;




		while(sfp_x <=103 || sfp_x >=596 || sfp_y<=103 || sfp_y >=596 )
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105; 
		}


		while(sfp_x >=240 && sfp_x <=265 && sfp_y>=290 && sfp_y <=410 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=290 && sfp_y<=410)
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;   
		}


		score=score+5;
		printf("%d\n",score);
	}

	//VERY HARD(WALLS)

	if((mode==77) && fp_x<=x[0]+7 && fp_x>=x[0] && fp_y<=y[0]+7 && fp_y>=y[0])
	{
		l_rec++;
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;

		while(fp_x <=103 || fp_x >=596 || fp_y<=104 || fp_y >=596 )
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105; 
		}
 		if(fp_x<104 || fp_x>597 || fp_y<103 || fp_y>596){
			printf("%d  %d\n",fp_x,fp_y);
		}
		

		while(fp_x >=245 && fp_x <=260 && fp_y>=295 && fp_y <=405 ||  fp_x>=445 && fp_x<=460 && fp_y>=295 && fp_y<=405 ||  fp_x>=445 && fp_x<=460 && fp_y>=475 && fp_y<=585 ||  fp_x>=120 && fp_x<=230 && fp_y>=245 && fp_y<=260 ||  fp_x>=245 && fp_x<=260 && fp_y>=115 && fp_y<=225 ||  fp_x>=445 && fp_x<=460 && fp_y>=115 && fp_y<=225 ||  fp_x>=245 && fp_x<=260 && fp_y>=475 && fp_y<=585 ||  fp_x>=120 && fp_x<=230 && fp_y>=430 && fp_y<=445 ||  fp_x>=475 && fp_x<=585 && fp_y>=430 && fp_y<=445 ||  fp_x>=475 && fp_x<=585 && fp_y>=245 && fp_y<=260)
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;  
		}
		score++;
		count++;
		if(count++) 
		{
			if(music2On){
	
		musicOn=false;
		PlaySound("Eat.wav",NULL, SND_ASYNC);
		
	}
			p_sam=0;
			sample=0;
		}
		printf("%d\n",score);  
        

		

	
	}


	//SPECIAL FOOD

	if((mode==77) && sfp_x<=x[0]+7 && sfp_x>=x[0] && sfp_y<=y[0]+7 && sfp_y>=y[0] && TF==1)
	{
		l_rec=l_rec+2;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;

		while(sfp_x <=104 || sfp_x >=596 || sfp_y<=104 || sfp_y >=596 )
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105; 
		}


		while(sfp_x >=240 && sfp_x <=265 && sfp_y>=290 && sfp_y <=410 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=290 && sfp_y<=410 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=470 && sfp_y<=590 ||  sfp_x>=115 && sfp_x<=235 && sfp_y>=240 && sfp_y<=265 ||  sfp_x>=240 && sfp_x<=265 && sfp_y>=110 && sfp_y<=230 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=110 && sfp_y<=230 ||  sfp_x>=240 && sfp_x<=265 && sfp_y>=470 && sfp_y<=590 ||  sfp_x>=115 && sfp_x<=235 && sfp_y>=425 && sfp_y<=450 ||  sfp_x>=470 && sfp_x<=590 && sfp_y>=430 && sfp_y<=450 ||  sfp_x>=470 && sfp_x<=590 && sfp_y>=240 && sfp_y<=265)
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;   
		}


		score=score+5;
		printf("%d\n",score);
	}
	
	//### For snake 2 ###

	//NORMAL FOOD

	if((mode==22 || mode==33) && fp_x<=x2[1]+7 && fp_x>=x2[1] && fp_y<=y2[1]+7 && fp_y>=y2[1])
	{
		l_rec2++;                              
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;

		while(fp_x <=104 || fp_x >=596 || fp_y<=104 || fp_y >=596 )
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105; 
		}
		if(fp_x<104 || fp_x>597 || fp_y<103 || fp_y>596){
			printf("%d  %d\n",fp_x,fp_y);
		}


		while(fp_x >=295 && fp_x <=405 && fp_y>=445 && fp_y <=460 ||  fp_x>=295 && fp_x<=405 && fp_y>=255 && fp_y<=260)
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;   
		}
		score++;
		count++;
		if(count++) 
		{
			if(music2On){
	
		musicOn=false;
		PlaySound("Eat.wav",NULL, SND_ASYNC);
		
	}
			p_sam=0;
			sample=0;
		}
		printf("%d\n",score);
	}

	//SPECIAL FOOD

	if((mode==22 || mode==33) && sfp_x<=x2[1]+7 && sfp_x>=x2[1] && sfp_y<=y2[1]+7 && sfp_y>=y2[1] && TF==1)
	{
		l_rec2=l_rec2+2;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;
		
		while(sfp_x <=104 || sfp_x >=596 || sfp_y<=104 || sfp_y >=596 )
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105; 
		}


		while(sfp_x >=290 && sfp_x <=410 && sfp_y>=440 && sfp_y <=465 ||  sfp_x>=290 && sfp_x<=410 && sfp_y>=250 && sfp_y<=265)
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;   
		}

		score=score+5;
		printf("%d\n",score);          
	
	}

	//VERY HARD LEVEL

	if((mode==99) && fp_x<=x2[1]+7 && fp_x>=x2[1] && fp_y<=y2[1]+7 && fp_y>=y2[1])
	{
		l_rec2++;
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;

		while(fp_x <=104 || fp_x >=595 || fp_y<=104 || fp_y >=595 )
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105; 
		}
		if(fp_x<104 || fp_x>597 || fp_y<103 || fp_y>596){
			printf("%d  %d\n",fp_x,fp_y);
		}

		while(fp_x >=145 && fp_x <=305 && fp_y>=540 && fp_y <=555 ||  fp_x>=145 && fp_x<=305 && fp_y>=395 && fp_y<=410 ||  fp_x>=145 && fp_x<=255 && fp_y>=440 && fp_y<=455 ||  fp_x>=145 && fp_x<=255 && fp_y>=495 && fp_y<=510 ||  fp_x>=240 && fp_x<=255 && fp_y>=445 && fp_y<=505 ||  fp_x>=295 && fp_x<=310 && fp_y>=395 && fp_y<=555 ||  fp_x>=395 && fp_x<=455 && fp_y>=540 && fp_y<=555 ||  fp_x>=445 && fp_x<=555 && fp_y>=440 && fp_y<=455 ||  fp_x>=445 && fp_x<=555 && fp_y>=495 && fp_y<=510 ||  fp_x>=395 && fp_x<=555 && fp_y>=395 && fp_y<=410 ||  fp_x>=445 && fp_x<=460 && fp_y>=445 && fp_y<=505 ||  fp_x>=395 && fp_x<=410 && fp_y>=395 && fp_y<=555 ||  fp_x>=395 && fp_x<=455 && fp_y>=150 && fp_y<=165 ||  fp_x>=445 && fp_x<=555 && fp_y>=195 && fp_y<=210 ||  fp_x>=395 && fp_x<=555 && fp_y>=295 && fp_y<=310 ||  fp_x>=445 && fp_x<=555 && fp_y>=245 && fp_y<=260 ||  fp_x>=445 && fp_x<=460 && fp_y>=195 && fp_y<=255 ||  fp_x>=395 && fp_x<=410 && fp_y>=150 && fp_y<=310 ||  fp_x>=145 && fp_x<=305 && fp_y>=150 && fp_y<=165 ||  fp_x>=145 && fp_x<=255 && fp_y>=195 && fp_y<=210 ||  fp_x>=240 && fp_x<=255 && fp_y>=195 && fp_y<=255 ||  fp_x>=295 && fp_x<=310 && fp_y>=150 && fp_y<=310 ||  fp_x>=145 && fp_x<=305 && fp_y>=295 && fp_y<=310 ||  fp_x>=145 && fp_x<=255 && fp_y>=245 && fp_y<=260)
		{
		fp_x=rand()%485+105;                              
		fp_y=rand()%485+105;   
		}
		score++;
		count++;
		if(count++) 
		{
			if(music2On){
	
		musicOn=false;
		PlaySound("Eat.wav",NULL, SND_ASYNC);
		
	}
			p_sam=0;
			sample=0;
		}
		printf("%d\n",score);
	}

	//SPECIAL FOOD

	if((mode==99) && sfp_x<=x2[1]+7 && sfp_x>=x2[1] && sfp_y<=y2[1]+7 && sfp_y>=y2[1] && TF==1)
	{
		l_rec2=l_rec2+2;
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;
		
		while(sfp_x <=103 || sfp_x >=596 || sfp_y<=103 || sfp_y >=596 )
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105; 
		}


		while(sfp_x >=140 && sfp_x <=310 && sfp_y>=535 && sfp_y <=560 ||  sfp_x>=140 && sfp_x<=310 && sfp_y>=390 && sfp_y<=415 ||  sfp_x>=140 && sfp_x<=260 && sfp_y>=435 && sfp_y<=460 ||  sfp_x>=140 && sfp_x<=260 && sfp_y>=490 && sfp_y<=515 ||  sfp_x>=235 && sfp_x<=260 && sfp_y>=440 && sfp_y<=510 ||  sfp_x>=290 && sfp_x<=315 && sfp_y>=390 && sfp_y<=560 ||  sfp_x>=390 && sfp_x<=460 && sfp_y>=535 && sfp_y<=560 ||  sfp_x>=440 && sfp_x<=560 && sfp_y>=435 && sfp_y<=460 ||  sfp_x>=440 && sfp_x<=560 && sfp_y>=490 && sfp_y<=515 ||  sfp_x>=390 && sfp_x<=560 && sfp_y>=390 && sfp_y<=415 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=440 && sfp_y<=510 ||  sfp_x>=390 && sfp_x<=415 && sfp_y>=390 && sfp_y<=560 ||  sfp_x>=390 && sfp_x<=460 && sfp_y>=145 && sfp_y<=170 ||  sfp_x>=440 && sfp_x<=560 && sfp_y>=190 && sfp_y<=215 ||  sfp_x>=390 && sfp_x<=560 && sfp_y>=290 && sfp_y<=315 ||  sfp_x>=440 && sfp_x<=560 && sfp_y>=240 && sfp_y<=265 ||  sfp_x>=440 && sfp_x<=465 && sfp_y>=190 && sfp_y<=260 ||  sfp_x>=390 && sfp_x<=415 && sfp_y>=145 && sfp_y<=315 ||  sfp_x>=140 && sfp_x<=310 && sfp_y>=145 && sfp_y<=170 ||  sfp_x>=140 && sfp_x<=260 && sfp_y>=190 && sfp_y<=215 ||  sfp_x>=235 && sfp_x<=260 && sfp_y>=190 && sfp_y<=260 ||  sfp_x>=290 && sfp_x<=315 && sfp_y>=145 && sfp_y<=315 ||  sfp_x>=140 && sfp_x<=310 && sfp_y>=290 && sfp_y<=315 ||  sfp_x>=140 && sfp_x<=260 && sfp_y>=240 && sfp_y<=265)
		{
		sfp_x=rand()%485+105;                              
		sfp_y=rand()%485+105;   
		}

		score=score+5;
		printf("%d\n",score);          
	
	}
}


 
#endif FoodCheck_H_INCLUDED