#ifndef Highscore_H_INCLUDED
#define Highscore_H_INCLUDED


static int score=0,mode;
double imgX=0,imgY=100,imgX1=605,imgY1=140, X=.3;
char sco[20];
int i,print=0;

int scores[5];
char names[5][21];
char show[6][80];
FILE *from;
bool read,high;
int typed,indx;


void highscoreset()//highscore function
{
	 iShowBMP(0, 0, "Game over.bmp");
		
		iText(200,650,"YOUR FINAL SCORE :",GLUT_BITMAP_TIMES_ROMAN_24);
		sprintf(sco,"%d",score);
		iText(460,650,sco,GLUT_BITMAP_TIMES_ROMAN_24);
		


		    iShowBMP(0, 430, "congrats.bmp");
			iSetColor(240,240,240);
			iText(20,120,"Enter your NAME: ",GLUT_BITMAP_TIMES_ROMAN_24);
	        iRectangle(250,100,300,50);
	         iText(260,120,show[5],GLUT_BITMAP_TIMES_ROMAN_24);
}


void High_scores(void)//file input function
{
	iClear();
	iSetColor(256,256,256);
    iFilledRectangle(0,0,700,700);

	if (!read)
	{
		if ( ( from = fopen( "HIGHSCORE.txt" , "r" ) ) == NULL)
		{
			from = fopen( "HIGHSCORE.txt" , "w" );
		
			for (int i=0; i<5; i++)
			{
				strcpy(names[i],"Unknown");
				scores[i]=0;
				fprintf( from, "%s: %d\n" , names[i] , scores[i] );
			}

			fclose(from);
		}

		from = fopen( "HIGHSCORE.txt" , "r" );

		i=0;

		while (!feof(from))
		{
			fgets(show[i],79,from);
			i++;
		}

		fclose(from);
		
		read=true;
	}
	iShowBMP(190,600,"bh3.bmp");
	iShowBMP(350,150,"hb.bmp");

	
	iSetColor(0,0,0);

		iText(100,500,"1.",GLUT_BITMAP_TIMES_ROMAN_24);
		iText(100,440,"2.",GLUT_BITMAP_TIMES_ROMAN_24);
		iText(100,380,"3.",GLUT_BITMAP_TIMES_ROMAN_24);
		iText(100,320,"4.",GLUT_BITMAP_TIMES_ROMAN_24);
		iText(100,260,"5.",GLUT_BITMAP_TIMES_ROMAN_24);

		iRectangle(260,20,150,30);
		iText(270,30,"> BACK TO MENU",  GLUT_BITMAP_8_BY_13);

	for (int i=0; i<5; i++)	
		iText(135,500-i*60,show[i],GLUT_BITMAP_TIMES_ROMAN_24);



}


void GameOver(){//for gameover funtion
		if (!read)
	{
		if ( ( from = fopen( "HIGHSCORE.txt" , "r" ) ) == NULL)
		{
			from = fopen( "HIGHSCORE.txt" , "w" );
		
				for (int i=0; i<5; i++)
			{
				strcpy(names[i],"Unknown");
				scores[i]=0;
				fprintf( from, "%s : %d\n" , names[i] , scores[i] );
			}
			

			fclose(from);
		}

		from = fopen( "HIGHSCORE.txt" , "r" );

		i=0;

		while (!feof(from))
		{
			fscanf(from,"%s  %d",&names[i],&scores[i]);
			i++;
		}

		fclose(from);
		
		read=true;

		for (i=0; i<5; i++)
			if (score>scores[i])
			{
				indx=i;
				
				for (int j=4; j>i; j--)
				{
					strcpy(names[j],names[j-1]);
					scores[j]=scores[j-1];
				}

				scores[i]=score;
				high=true;
				break;
			}
	}

	if (high)
		
	   
	{
		iClear();
		print=2;
		 iShowBMP(0, 0, "gv.bmp");
		
		iText(200,650,"YOUR FINAL SCORE :",GLUT_BITMAP_TIMES_ROMAN_24);
		sprintf(sco,"%d",score);
		iText(460,650,sco,GLUT_BITMAP_TIMES_ROMAN_24);
		
			typed=0;
			show[5][0]='\0';
			mode=12345;
				

			
		
	}
}
	// Every time Prints the score on the window 
    void ScorePrint(){
	sprintf(sco,"%d",score); 
	iSetColor(255,255,255);
	iRectangle(535,645,100,22);
	iText(555,650,"SCORE:",GLUT_BITMAP_HELVETICA_12);
	iText(600,650,sco,GLUT_BITMAP_HELVETICA_12);
}







#endif  Highscore_H_INCLUDED