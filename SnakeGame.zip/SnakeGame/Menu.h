#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

static int  var=0;
int s_x=0,s_y=0,g_x=500,g_y=0;//this is the  snake move 
int ng_x=-150,ng_y=440;//this is for game move
int ab_x=700,ab_y=370;//this for about
int hs_x=-150,hs_y=300; //this is for about
int ex_x=700,ex_y=230; //this is for exist

void SGMove(){ //This is for the moving 'SNAKE GAME' of the MENU 
	
	iShowBMP(s_x, s_y, "S.bmp");
	iShowBMP(g_x, g_y, "G.bmp");
	if(var==0){
	s_y=s_y+1;
	g_y=g_y+1;
	
	}
	if(s_y==520 && g_y==520 && s_x!= 150 && g_x!=360 ){
		s_x=s_x+1;
		g_x=g_x-1;
		var=2;
	
	}
	if(s_x==150 && g_x==350 ){
		s_x=150;
		g_x=360;
		
		var=2;
	}
	

}

void NGMove(){ //this is for the moving new game option
		iRectangle(ng_x,ng_y,150,35);		
		iText(ng_x,ng_y+10," > NEW GAME",GLUT_BITMAP_HELVETICA_18);
		if( ng_x<280)
		ng_x=ng_x+1;
		if (ng_x==280)
			ng_x=ng_x;
		
}

void ABMove(){//this is for moving new game option
		iRectangle(ab_x,ab_y,150,35);		
		iText(ab_x,ab_y+10," > ABOUT",GLUT_BITMAP_HELVETICA_18);
		if(ab_x>280)
			ab_x=ab_x-1;
		if(ab_x==280)
			ab_x=ab_x;
}

void HSMove(){//this is for moving highest score option
		iRectangle(hs_x,hs_y,150,35);		
		iText(hs_x,hs_y+10," > HIGH SCORE",GLUT_BITMAP_HELVETICA_18);
		if(hs_x<280)
			hs_x=hs_x+1;
		if(hs_x==280)
			hs_x=hs_x;
}

void EXMove(){//this is for moiving exist option
		iRectangle(ex_x,ex_y,150,35);
		iText(ex_x,ex_y+10," > EXIT",GLUT_BITMAP_HELVETICA_18);
		if(ex_x>280)
			ex_x=ex_x-1;
		if(ex_x==280)
			ex_x=ex_x;
}















#endif MENU_H_INLUDED