# include "iGraphics.h"
# include "stdio.h"
# include "stdlib.h"
# include "string.h"
# include "Menu.h"
# include "Highscore.h"
# include "FoodCheck.h"
# include "WallCheck1.h"
# include "ControlSnake.h"
# include "SnakeCheck.h"
# include "LimitCheck.h"
# include "Background.h"





int c,c1,c2,c3;//for random color change
int t=150;



static unsigned char p_key=GLUT_KEY_LEFT;
unsigned char keys;
int ticker_x=245,ticker_y=450;  








void iDraw()
{

	//printf("Count: %d\n,",count);

	c=c+rand()%240;
	c1=c1+rand()%240;
	c2=c2+rand()%240;
	c3=c3+rand()%240;


	//High Score

	if(mode==123){
		High_scores();
	}
	
	if(mode==12345){
		iClear();
		highscoreset();			
	}

	if(print==321){

		iClear();
		High_scores();
	}


	//Enter to star game

	if(mode==1000){
		iClear();
		iShowBMP(0, 0, "snake3.bmp");
		iSetColor(0,0,0);
		iText(290,650,"Press ENTER to START GAME.",GLUT_BITMAP_HELVETICA_18);
	}


	//STARTING

	if(mode==0){
		iClear();

		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);        
		SGMove();
		
		
		if(var==2){
			
		iSetColor(0,0,0);
		

        NGMove();
		ABMove();
		HSMove();
		EXMove();




		if (ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
			iSetColor(256,0,0);
			iText(ticker_x, ticker_y, "=>",GLUT_BITMAP_TIMES_ROMAN_24);
			iShowBMP(260, 10, "up.bmp");
		}



		}

	}






	//Select snake type

	if(mode==11)
	{
		iClear();
		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);
		

	

		iSetColor(0,0,0);

		iRectangle(20,640,210,40);		
		iText(30,650," > SNAKE TYPES",GLUT_BITMAP_TIMES_ROMAN_24);
		iSetColor(256,0,0);
		iText(ticker_x,ticker_y," => ",GLUT_BITMAP_TIMES_ROMAN_24);
		
		iSetColor(0,0,0);
		iRectangle(270,640,130,35);	
		iText(280,650,"(1) ",GLUT_BITMAP_HELVETICA_18);       
		iFilledRectangle(310,650,28,7);                          

		iRectangle(270,590,130,35);
		iText(280,600,"(2) ",GLUT_BITMAP_HELVETICA_18);
		iFilledCircle(313.5,605,3.5);
		iRectangle(317,601,7,7);
		iRectangle(325,601,7,7);
		iRectangle(333,601,7,7);

		
		iRectangle(600,20,80,30);
		iText(610,30,"> BACK",  GLUT_BITMAP_8_BY_13);

		iShowBMP(240, 180, "d.bmp");
	}


	// Level's option (Snake 1)

	if(mode==1 )
	{
		iClear();
		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);



		iSetColor(0,0,0);
		iRectangle(250,640,140,40);
		iRectangle(255,645,130,30);
		iText(260,650," > LEVELS",GLUT_BITMAP_TIMES_ROMAN_24);
		

		iSetColor(256,0,0);
		iText(ticker_x,ticker_y,"=>",GLUT_BITMAP_TIMES_ROMAN_24);
		iSetColor(0,0,0);
		iRectangle(30,550,140,35);		
		iText(40,560,"1. NORMAL",GLUT_BITMAP_HELVETICA_18);
		
		iRectangle(30,500,140,35);
		iText(40,510,"2. HARD",GLUT_BITMAP_HELVETICA_18);

		iRectangle(30,450,140,35);
		iText(40,460,"3. VERY HARD",GLUT_BITMAP_HELVETICA_18);

		iRectangle(600,20,80,30);
		iText(610,30,"> BACK",  GLUT_BITMAP_8_BY_13);
		iShowBMP(380, 250, "m.bmp");

		
	}


	// Level's option (Snake 2)

	if(mode==100)
	{
		iClear();
		iSetColor(248,248,248);
		iFilledRectangle(0,0,700,700);



		iSetColor(0,0,0);
		iRectangle(250,540,140,45);
		iRectangle(255,545,130,35);
		iText(260,550," > LEVELS",GLUT_BITMAP_TIMES_ROMAN_24);

		iSetColor(256,0,0);
		iText(ticker_x,ticker_y,"=>",GLUT_BITMAP_TIMES_ROMAN_24);

		iSetColor(0,0,0);
		iRectangle(250,450,150,35);		                                
		iText(260,460,"1. NORMAL",GLUT_BITMAP_HELVETICA_18);        
		
		iRectangle(250,400,150,35);
		iText(260,410,"2. HARD",GLUT_BITMAP_HELVETICA_18);

		iRectangle(250,350,150,35);
		iText(260,360,"3. VERY HARD",GLUT_BITMAP_HELVETICA_18);

		iRectangle(600,50,80,30);
		iText(610,60,"> BACK",  GLUT_BITMAP_8_BY_13);

		

		
	}



	//About


	if(mode==6)
	{
		

		iClear();
		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);

		iSetColor(0,0,0);
		

		
	
		iShowBMP(0, 50, "about.bmp");
		iRectangle(600,20,80,25);
		iText(610,30,"> BACK",  GLUT_BITMAP_8_BY_13);
		iText(220,20,"ENJOY THE GAME",GLUT_BITMAP_HELVETICA_18);
	




	}
		
	// ###GAME RUNNING (Snake 1)###

	//Normal 
	
	if(mode==2)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
	
    iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
	iSetColor(256,0,0);
	iRectangle(100,100,500,500);

	iSetColor(256,256,256);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);


	iSetColor(c*c1,c2*c,c3*c);

    for(int i=0;i<=l_rec;i++){

	iFilledRectangle(x[i],y[i],7,7);


	}
	iSetColor(0,0,256);
	iFilledRectangle(x[0],y[0],7,7);
	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	
	
	

	
	}
	

	//Hard

	
	if(mode==3)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
	
	iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
			iSetColor(256,0,0);
	iRectangle(100,100,500,500);

	iSetColor(256,256,256);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);
	

	iSetColor(250,0,0);
	iFilledRectangle(250,300,5,100);   //Low wall   
	


	iSetColor(250,0,0);
	iFilledRectangle(450,300,5,100);
	iSetColor(220,0,0);              //Upper wall



	iSetColor(c*c1,c*c2,c*c3);

    for(int i=0;i<=l_rec;i++){

	iFilledRectangle(x[i],y[i],7,7);

	}
	iSetColor(0,0,256);
	iFilledRectangle(x[0],y[0],7,7);
	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	
	}
	

	//VERY HARD


		
	if(mode==77)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
	iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
			iSetColor(256,0,0);
	iRectangle(100,100,500,500);

	iSetColor(256,256,256);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);
	

	iSetColor(250,0,0);
	iFilledRectangle(250,300,5,100);   //Lower walls
	iFilledRectangle(450,480,5,100);
	iFilledRectangle(125,250,100,5);
	iFilledRectangle(250,120,5,100);
	iFilledRectangle(450,120,5,100);
	
	


	iSetColor(250,0,0);
	iFilledRectangle(450,300,5,100);
	iFilledRectangle(250,480,5,100);
	iFilledRectangle(125,435,100,5);
	iFilledRectangle(480,435,100,5);
	iFilledRectangle(480,250,100,5);
	iSetColor(220,0,0);              //Upper walls



	iSetColor(c*c1,c*c2,c*c3);

    for(int i=0;i<=l_rec;i++){

	iFilledRectangle(x[i],y[i],7,7);

	}
	iSetColor(0,0,256);
	iFilledRectangle(x[0],y[0],7,7);
	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	
	}
	

 
	
	//### Game running (Snake 2) ###

      //Normal
	if(mode==22)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
	iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
			iSetColor(256,0,0);
	iRectangle(100,100,500,500);

	iSetColor(256,256,256);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);

	iSetColor(c*c1,c*c2,c*c3);	
	iFilledCircle(x2[0],y2[0],3.3);
	for(int i=1;i<=l_rec2;i++)
	{
		iRectangle(x2[i],y2[i],7,7);
	}



	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	

	}


	//Hard

	if( mode ==33)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
	iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
iSetColor(256,0,0);
	iRectangle(100,100,500,500);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);

	iSetColor(250,0,0);
	iFilledRectangle(300,450,100,5);   //Low wall 
	


	iSetColor(250,0,0);
	iFilledRectangle(300,250,100,5);
	iSetColor(220,0,0);              //Upper wall

	iSetColor(c*c1,c*c2,c*c3);
	iFilledCircle(x2[0],y2[0],3.5);
	for(int i=1;i<=l_rec2;i++)
	{
		iRectangle(x2[i],y2[i],7,7);
	}


	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	

	}


	//VERY HARD MODE
	if( mode ==99)
	{
	iClear();
	iSetColor(0,64,0);
	iFilledRectangle(0,0,700,700);
	iShowBMP(150,20, "S.bmp");
	iShowBMP(360,20, "G.bmp");
    iSetColor(85,0,0);
	iFilledRectangle(100,100,500,500);
			iSetColor(256,0,0);
	iRectangle(100,100,500,500);

	iSetColor(256,256,256);
	iText(250,680,"Press 'p' or 'P' to PAUSE the game.",GLUT_BITMAP_HELVETICA_12);
	


	iSetColor(250,0,0);
	iFilledRectangle(150,545,150,5); 
	iFilledRectangle(150,400,150,5);	//upper wall 
	iFilledRectangle(150,445,100,5);
	iFilledRectangle(150,500,100,5);
	iFilledRectangle(245,450,5,50);
	iFilledRectangle(300,400,5,150);

	iFilledRectangle(400,545,150,5);
	iFilledRectangle(450,445,100,5);
	iFilledRectangle(450,500,100,5);
	iFilledRectangle(400,400,150,5);
	iFilledRectangle(450,450,5,50);
	iFilledRectangle(400,400,5,150);

	iSetColor(250,0,0);
	iFilledRectangle(400,155,150,5);	//lower wall
	iFilledRectangle(450,200,100,5);
	iFilledRectangle(400,300,150,5);
	iFilledRectangle(450,250,100,5);
	iFilledRectangle(450,200,5,50);
	iFilledRectangle(400,155,5,150);

	iFilledRectangle(150,155,150,5);
	iFilledRectangle(150,200,100,5);
	iFilledRectangle(245,200,5,50);
	iFilledRectangle(300,155,5,150);
	iFilledRectangle(150,300,150,5);
	iFilledRectangle(150,250,100,5);
	iSetColor(220,0,0);				

	iSetColor(c*c1,c*c2,c*c3);
	iFilledCircle(x2[0],y2[0],3.5);
	for(int i=1;i<=l_rec2;i++)
	{
		iRectangle(x2[i],y2[i],7,7);
	}


	iSetColor(256,256,256);
	iFilledCircle(fp_x,fp_y,2);
	Special();
	ScorePrint();
	

	}




//1st SNAKE
	//GAME PAUSED (normal)

	if(mode==4 || mode==8 || mode==770)
	{
		iClear();
		
		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);


		iSetColor(c*c2,c*c3,c*c1);
	
		SGMove();
		
		iSetColor(256,0,0);
		iText(ticker_x,ticker_y,"=>",GLUT_BITMAP_TIMES_ROMAN_24);
		iSetColor(0,0,0);
		iRectangle(280,370,150,35);			
		iText(280,380," > RESUME",GLUT_BITMAP_HELVETICA_18);
		
		iRectangle(280,290,150,35);
		iText(280,300," > EXIT",GLUT_BITMAP_HELVETICA_18);

		
	}


	

	//2nd SNAKE

	//Game Paused(Normal)
	if(mode==44 || mode==88 || mode==990)
	{
		iClear();
		SGMove();

		iSetColor(256,256,256);
		iFilledRectangle(0,0,700,700);


		iSetColor(c*c2,c*c3,c*c1);
		
        SGMove();
		
		iSetColor(0,0,0);
		iRectangle(280,370,150,35);
		iSetColor(256,0,0);
		iText(ticker_x,ticker_y,"=>",GLUT_BITMAP_TIMES_ROMAN_24);
		iSetColor(0,0,0);
		iText(280,380," > RESUME",GLUT_BITMAP_HELVETICA_18);
		
		iRectangle(280,290,150,35);
		iText(280,300," > EXIT",GLUT_BITMAP_HELVETICA_18);
		
	}


	
		//LIMIT CROSSED


	if(mode==5)
	{
		if(musicOn || music2On){
	
		musicOn=false;
		music2On=false;
		PlaySound("gv.wav",NULL, SND_ASYNC);
		
	}
        iShowBMP(0, 0, "gv.bmp");
		
		iText(200,650,"YOUR FINAL SCORE :",GLUT_BITMAP_TIMES_ROMAN_24);
		sprintf(sco,"%d",score);
		iText(460,650,sco,GLUT_BITMAP_TIMES_ROMAN_24);

		iText(100,50,"Press 'ENTER' to go BACK TO MAIN MENU.",GLUT_BITMAP_TIMES_ROMAN_24);

		read=false;
		high=false;
		GameOver();

	for(int k=0;k<=8;k++){  //This stops all the times except the timer which moves the snake at the start of a new game
	  iPauseTimer(k);
	 }
      iResumeTimer(8);


		
	}

	
}



	

/* 
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
}

/* 
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN )
	{
		if(mx>=280 && mx<=430 && my>=440 && my<=475 && mode==0)    //New game 
		{
			mode=11;
			ticker_x=230;
	        ticker_y=650;
		}

		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==0)    //About menu	
		{
			mode=6;
		}
		if(mx>=280 && mx<=430 && my>=300 && my<=435 && mode==0)    //High score	
		{
			mode=123;
		}
				if(mx>=260 && mx<=410 && my>=20 && my<=50 && (mode==123 || print==321))     // High Score inside (Back to menu) 
		{
read=false;
typed=0;
indx=0; 

ticker_x=245;
ticker_y=450;
count=0;
score=0;
print=0;
l_rec=4;
l_rec2=4;
l_rec3=4;
l_rec4=4;
p_key=GLUT_KEY_LEFT;
ticker_x=245;
ticker_y=450;
fp_x=255;
fp_y=250;


	x[0]=350;
	y[0]=150;


	x2[0]=351;
	y2[0]=150;
	x2[1]=354;
	y2[1]=146;


	x3[0]=350;
	y3[0]=250;

	x4[0]=351;
	y4[0]=450;
	x4[1]=354;
	y4[1]=446;
	

	for(int i=0;i<=l_rec;i++){
		x[i+1]=x[i]+7;
		y[i+1]=y[i];
	}

		for(int j=1;j<=l_rec2;j++){
		x2[j+1]=x2[j]+7;
		y2[j+1]=y2[j];
	}

		for(int k=0;k<=l_rec3;k++){
		x3[k+1]=x3[k]+7;
		y3[k+1]=y3[k];
	}

		for(int n=1;n<=l_rec4;n++){
		x4[n+1]=x4[n]+7;
		y4[n+1]=y4[n];

	}
		
		mode=0;

		}


		if(mx>=280 && mx<=430 && my>=230 && my<=265 && mode==0)   //Exit
		{
			exit(0);
		}

		if(mx>=600 && mx<=680 && my>=20 && my<=50 && mode==1)     // New Game (Back to menu) 
		{
			mode=0;
			ticker_x=245;
            ticker_y=450;

		}

		if(mx>=600 && mx<=680 && my>=20 && my<=50 && mode==6)     // About inside (Back to menu) 
		{
			mode=0;
			ticker_x=245;
            ticker_y=450;
		}

		if(mx>=600 && mx<=680 && my>=20 && my<=50 && mode==11 )     // Select snake (Back to menu) 1st snake
		{
			mode=0;
			ticker_x=245;
            ticker_y=450;
		}

		if(mx>=600 && mx<=680 && my>=50 && my<=80 && mode==100 )     // Select snake (Back to menu) 2nd snake
		{
			mode=0;
			ticker_x=245;
            ticker_y=450; 
			
		}





		if(mx>=270 && mx<=400 && my>=640 && my<=675 && mode==11)   //Select 1 no snake  
		{
			mode=1;
			ticker_x=0;
	        ticker_y=560;
		}

		if(mx>=270 && mx<=400 && my>=590 && my<=625 && mode==11)    //Select 2 no snake  
		{
			mode=100;
		    ticker_x=220;
  	        ticker_y=460;

		
		}

	
	
		

		//SNAKE 2 


        if(mx>=250 && mx<=400 && my>=450 && my<=485 && mode ==100)  //Normal (snake 2)
		{
			mode=22;
		}
        if(mx>=250 && mx<=400 && my>=400 && my<=435 && mode ==100)  //Hard (Snake 2)
		{
			mode=33;
		}

        if(mx>=250 && mx<=400 && my>=350 && my<=385 && mode ==100)  //Very hard Hard (Snake 2)
		{
			mode=99;
		}


		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==44)    //Resume game(normal) 	Snake 2
		{
			mode=22;
		}

		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==88)    //Resume game(hard) 	Snake 2
		{
			mode=33;
		}

		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==990)    //Resume game(Very hard) 	Snake 2
		{
			mode=99;
		}
		
		



		//SNAKE 1 
		

		if(mx>=30 && mx<=170 && my>=550 && my<=585 && mode==1)   //Normal level
		{
			mode=2;
		}

		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==4)    //Resume game(normal) 	
		{
			mode=2;
		}

		
		if(mx>=30 && mx<=170 && my>=500 && my<=535 && mode==1)   //Hard level
		{
			mode=3;
		}
		
		
		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==8)    //Resume game(hard) 	
		{
			mode=3;
		}

		if(mx>=30 && mx<=170 && my>=450 && my<=485 && mode==1)   //Very Hard level
		{
			mode=77;
		}
		if(mx>=280 && mx<=430 && my>=370 && my<=405 && mode==770)    //Resume game(Very hard) 	
		{
			mode=77;
		}
	



		if(mx>=280 && mx<=430 && my>=290 && my<=325 && (mode==4 || mode ==44 || mode==8 || mode==88 || mode==48 || mode==770 || mode==990 ) )  //Exit 
		{

			exit(0);
		}

	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
    }


}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed. 
*/
void iKeyboard(unsigned char key)
{
	if(key=='m'){
	if(musicOn){
	musicOn=false;
	PlaySound(0,0,0);
	}else{
		musicOn=true;
		PlaySound("s.wav",NULL,SND_LOOP | SND_ASYNC);
	}}
	if(key=='n'){
	if(musicOn){
	musicOn=false;
	PlaySound(0,0,0);
	}else{
		musicOn=true;
		PlaySound("gv.wav",NULL, SND_ASYNC);
	}}
	//HIGH SCORE INPUT

	if(print==2){
{
		if ( (key>='A' && key<='Z') || (key>='a' && key<='z') || (key>='0' && key<='9'))
		{
			show[5][typed++]=key;
			show[5][typed]='\0';
		}
		else if ( key=='\r')
		{
			strcpy(names[indx],show[5]);

			from = fopen( "HIGHSCORE.txt" , "w" );
		
			for (int i=0; i<5; i++)
				fprintf( from, "%s %d\n" , names[i] , scores[i] );

			fclose(from);
			read=false;
			mode=12345;
		}
	}

	}

	if(key=='\r' && mode==12345){
		print=321;
	}



	//Click  RESUME the PAUSED GAME

    if(key=='\r' &&  ticker_y==380 && mode==4 ){
	    mode=2;
	}
    if(key=='\r' &&  ticker_y==380 && mode==8 ){
	    mode=3;
	}
    if(key=='\r' &&  ticker_y==380 && mode==44 ){
		mode=22;
	}
    if(key=='\r' &&  ticker_y==380 && mode==88 ){
		mode=33;
	}
    if(key=='\r' &&  ticker_y==380 && mode==48 ){
		mode=23;
	}
    if(key=='\r' &&  ticker_y==380 && mode==770 ){
		mode=77;
	}
    if(key=='\r' &&  ticker_y==380 && mode==990 ){
		mode=99;
	}

	if(key=='\r' &&  ticker_y==300 && (mode==4 || mode==8 || mode==44 || mode==88 || mode==48 || mode==770 || mode==990)){
	    exit(0);
	}

	if(key=='\r' && mode==1 && ticker_y==560){ //For SNAKE 1(NORMAL)
	    mode=2;
	}
	if(key=='\r' && mode==1 && ticker_y==510){ //For SNAKE 1(HARD)
		mode=3;
	}
	if(key=='\r' && mode==1 && ticker_y==460){ //For SNAKE 1( very HARD)
	mode=77;
	}

	if(key=='\r' && mode==100 && ticker_y==460){ //For SNAKE 2(NORMAL)
	mode=22;
	}
	if(key=='\r' && mode==100 && ticker_y==410){  //For SNAKE 2 (HARD)
		mode=33;
	}
	if(key=='\r' && mode==100 && ticker_y==360){  //For SNAKE 2 ( very HARD)
		mode=99;
	}
	


	if(key=='\r' && mode==11 && ticker_y==650){  // Enter levels option of snake 1
	mode=1;
	ticker_x=0;
	ticker_y=560;
	}


	if(key=='\r' && mode==11 && ticker_y==600){  // Enter levels option of snake 2
	mode=100;
	ticker_x=220;
	ticker_y=460;
	}





	
	if(key=='\r' && mode==0 && ticker_y==450 ){ //Press ENTER at NEW GAME
	mode=11;
	ticker_x=230;
	ticker_y=650;
}

	if(key=='\r' && mode==0 && ticker_y==380 ){ //Press ENTER at ABOUT
	mode=6;
	} 

	// FOR HIGH SCORE
	if(key=='\r' && mode==0 && ticker_y==310 ){ //Press ENTER at High score
	mode=123;
	} 
	
	  if(key=='\r' && mode==0 && ticker_y==310 ){
	mode=11;
}  	

	if(key=='\r' && mode==0 && ticker_y==240 ){
	exit(0);
}

if(key=='\r' && mode==1000)  // Press ENTER to START THE GAME
{
	mode=0;

}
//Press BACKSPACE to go to previous page

if(key=='\b' && (mode==11 || mode==6 || mode==123)){   
	mode=0;
	ticker_x=245;
	ticker_y=450;
}


if(key=='\b' && (mode==1 || mode==100)){
	mode=11;
	ticker_x=230;
	ticker_y=650;
}

	
if((key=='p' || key=='P') && mode==2 )
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=4;
		ticker_x=250;
		ticker_y=380;
	}

if((key=='p' || key=='P') && mode==3)
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=8;
		ticker_x=250;
		ticker_y=380;
	}
if((key=='p' || key=='P') && mode==77)
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=770;
		ticker_x=250;
		ticker_y=380;
	}

if((key=='p' || key=='P') && mode==22 )
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=44;
		ticker_x=250;
		ticker_y=380;
	}


if((key=='p' || key=='P') && mode==33)
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=88;
		ticker_x=250;
		ticker_y=380;
	}
if((key=='p' || key=='P') && mode==99)
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=990;
		ticker_x=250;
		ticker_y=380;
	}
if((key=='p' || key=='P')  && mode==23)
	{	   
		for(int b=0;b<=8;b++)
		iPauseTimer(b);
		mode=48;
		ticker_x=250;
		ticker_y=380;
	}




if(key=='\r' && mode==5){
		
typed=0;
indx=0;


count=0;
score=0;
print=0;
l_rec=4;
l_rec2=4;
l_rec3=4;
l_rec4=4;
p_key=GLUT_KEY_LEFT;
ticker_x=245;
ticker_y=450;
fp_x=255;
fp_y=250;


	x[0]=350;
	y[0]=150;


	x2[0]=351;
	y2[0]=150;
	x2[1]=354;
	y2[1]=146;


	x3[0]=350;
	y3[0]=250;

	x4[0]=351;
	y4[0]=450;
	x4[1]=354;
	y4[1]=446;
	

	for(int i=0;i<=l_rec;i++){
		x[i+1]=x[i]+7;
		y[i+1]=y[i];
	}

		for(int j=1;j<=l_rec2;j++){
		x2[j+1]=x2[j]+7;
		y2[j+1]=y2[j];
	}

		for(int k=0;k<=l_rec3;k++){
		x3[k+1]=x3[k]+7;
		y3[k+1]=y3[k];
	}

		for(int n=1;n<=l_rec4;n++){
		x4[n+1]=x4[n]+7;
		y4[n+1]=y4[n];

	}
		
		mode=0;
}

}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use 
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6, 
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12, 
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP, 
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT 
*/
void iSpecialKeyboard(unsigned char key)
{
	
		
	

	if(key== GLUT_KEY_UP && p_key!=GLUT_KEY_UP && (mode==2 || mode==3 ||  mode==77 || mode==22 || mode==33 || mode==99 || mode==23) )
{ 


	if(p_key==GLUT_KEY_LEFT){
    p_key=key;
	MoveUp_FromLeft();
	}
	 if(p_key==GLUT_KEY_RIGHT){
		p_key=key;
    MoveUp_FromRight();
	
	}
	
    	
	while(key!= GLUT_KEY_UP  )
 
	{
	
	break;}
	

}
if(key== GLUT_KEY_DOWN && p_key!=GLUT_KEY_DOWN && (mode==2 || mode==3 ||  mode==77 || mode==22 || mode==33 || mode==99 || mode==23))
{
	
	if(p_key== GLUT_KEY_LEFT){
		p_key=key;
	MoveDown_FromLeft();
	}

	if(p_key==GLUT_KEY_RIGHT){
		p_key=key;
	MoveDown_FromRight();
	}
	
	
	while(key!= GLUT_KEY_DOWN )
	{
	break;}
	
	
}

if (key== GLUT_KEY_LEFT && p_key!= GLUT_KEY_LEFT && (mode==2 || mode==3 ||  mode==77 || mode==22 || mode==33 || mode==99 || mode==23))
{ 
		
		
	if(p_key== GLUT_KEY_UP){
		p_key=key;


	MoveLeft_FromUp();
	
	}

	if(p_key==GLUT_KEY_DOWN){
		p_key=key;
	MoveLeft_FromDown();
	
	}
	
	while(key!= GLUT_KEY_LEFT)
	{
	break;}
	

}

if (key== GLUT_KEY_RIGHT && p_key!= GLUT_KEY_RIGHT && (mode==2 || mode==3 ||  mode==77 || mode==22 || mode==33 || mode==99 || mode==23))
{	
	

	if(p_key== GLUT_KEY_UP){
		p_key=key;
	MoveRight_FromUp();
	}

	if(p_key==GLUT_KEY_DOWN){
		p_key=key;
	MoveRight_FromDown();
	}

	while(key!= GLUT_KEY_LEFT)
	{
	break;}
	
}
//These are for moving TICKER when game paused

if(key==GLUT_KEY_UP && ticker_y==300 && (mode==4 || mode==8 || mode==44 || mode==88 || mode==48 || mode==770 || mode==990)){
	ticker_y=380;
}

if(key==GLUT_KEY_DOWN && ticker_y==380 && (mode==4 || mode==8 || mode==44 || mode==88 || mode==48 || mode==770 || mode==990)){
	ticker_y=300;
}

//These are for moving TICKER in SNAKE 2 option


if(key==GLUT_KEY_UP && ticker_y==410 && mode==100){
	ticker_y=460;
}
if(key==GLUT_KEY_UP && ticker_y==360 && mode==100){
	ticker_y=410;
}

if(key==GLUT_KEY_DOWN && ticker_y==410 && mode==100){
	ticker_y=360;
}
if(key==GLUT_KEY_DOWN && ticker_y==460 && mode==100){
	ticker_y=410;
}


//These are for moving TICKER in SNAKE 1 option


if(key==GLUT_KEY_UP && ticker_y==510 && mode==1){
	ticker_y=560;
}
if(key==GLUT_KEY_UP && ticker_y==460 && mode==1){
	ticker_y=510;
}


if(key==GLUT_KEY_DOWN && ticker_y==510 && mode==1){
	ticker_y=460;
}
if(key==GLUT_KEY_DOWN && ticker_y==560 && mode==1){
	ticker_y=510;
}



//This lines are for moving TICKER in SNAKE'S TYPE


if(key==GLUT_KEY_UP && ticker_y==600 && mode==11){
	ticker_y=650;
}
if(key==GLUT_KEY_UP && ticker_y==550 && mode==11){
	ticker_y=600;
}
if(key==GLUT_KEY_DOWN && ticker_y==600 && mode==11){
	ticker_y=550;
}
if(key==GLUT_KEY_DOWN && ticker_y==650 && mode==11){
	ticker_y=600;
}




//This lines are for moving the TICKER in the menu 

if(key== GLUT_KEY_UP && mode==0 && ticker_y==380 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=450;
}
if(key== GLUT_KEY_UP && mode==0 && ticker_y==310 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=380;
}
if(key== GLUT_KEY_UP && mode==0 && ticker_y==240 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=310;
}
if(key== GLUT_KEY_DOWN && mode==0 && ticker_y==310 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=240;
}
if(key== GLUT_KEY_DOWN && mode==0 && ticker_y==380 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=310;
}
if(key== GLUT_KEY_DOWN && mode==0 && ticker_y==450 && ng_x==280 && ab_x==280 && hs_x==280 && ex_x==280){
	ticker_y=380;

}

}

int main()
{
	//place your own initialization codes here.
	


	mode=1000;
//for snake 1 co-ordinate initializing
	x[0]=350;
	y[0]=150;
//for snake 2 co-ordinate initializing
	x2[0]=351;
	y2[0]=150;
	x2[1]=354;
	y2[1]=146;

	
	x3[0]=350;
	y3[0]=250;

	
	x4[0]=351;
	y4[0]=450;
	x4[1]=354;
	y4[1]=446;
	

	for(int i=0;i<=l_rec;i++){
		x[i+1]=x[i]+7;
		y[i+1]=y[i];
	}

		for(int j=1;j<=l_rec2;j++){
		x2[j+1]=x2[j]+7;
		y2[j+1]=y2[j];
	}

		for(int k=0;k<=l_rec3;k++){
		x3[k+1]=x3[k]+7;
		y3[k+1]=y3[k];
	}

		for(int n=1;n<=l_rec4;n++){
		x4[n+1]=x4[n]+7;
		y4[n+1]=y4[n];
	}

		fp_x=255;
		fp_y=250;
		
	iSetTimer(t,MoveUp_FromLeft);   
	iPauseTimer(0);
	iSetTimer(t,MoveUp_FromRight);
	iPauseTimer(1);
	iSetTimer(t,MoveDown_FromLeft);
	iPauseTimer(2);
	iSetTimer(t,MoveDown_FromRight);
    iPauseTimer(3);
	iSetTimer(t,MoveLeft_FromUp);
	iPauseTimer(4);
	iSetTimer(t,MoveLeft_FromDown);
	iPauseTimer(5);
	iSetTimer(t,MoveRight_FromUp);
	iPauseTimer(6);
	iSetTimer(t,MoveRight_FromDown);
	iPauseTimer(7);
	
	if(musicOn)
		PlaySound("s.wav",NULL,SND_LOOP | SND_ASYNC);
	else
		PlaySound("gv.wav",NULL, SND_ASYNC);




	iInitialize(700, 700, "Snake Game");
	
	return 0;
}	