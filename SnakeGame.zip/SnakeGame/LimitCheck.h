#ifndef LimitCheck_H_INCLUDED
#define LimitCheck_H_INCLUDED


//gameover function
void LimitCheck() 
{
	
	//For snake 1
	if(x[0]<=97.6 || y[0]<=100 || x[0]>=595 || y[0]>=598)
	{
		mode=5;
		

	}
	//For snake 2

		if(x2[0]<=99 || y2[0]<=101 || x2[0]>=598.5 || y2[0]>=598.5)
	{
		mode=5;

	}



}


#endif LimitCheck_H_INCLUDED